 #include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>
#include "util.h"
#include "complex.h"
#define NR_END 1

//0.25 0.5 1

int nx, ny, nz, it, count, n_level, c_relax;
double gam, lam, dt, h, h2, xleft, xright, yleft, yright, zleft, zright, pi,
    oE, ***c1, ***c2,
    ***ct, ***sc, ***intc, ***ooc, Sb, ***sorc, lamm, Q;
void print_vol(double ***aa, int yu, int yd, int xl, int xr, int zl, int zr, int num);

int main()
{
   extern int nx, ny, nz, it, count, n_level, c_relax;
   extern double gam, dt, h, h2, xleft, xright, yleft, yright, zleft, zright, pi,
       oE, ***c1, ***c2,
       ***ct, ***sc, ***intc, ***ooc, Sb, ***sorc, Q;

   int i, j, k, max_it, ns;
   double ***oc, ***nc, ***gf, cahn;
   double elapsed, start, T, end;

   FILE *my, *myME, *myCE, *myOE;

   start = clock();

   pi = 4.0 * atan(1.0);

   nx = gnx;
   ny = gny;
   nz = gnz;

   xleft = 0.0, xright = 0.5;
   yleft = 0.0, yright = xright * ny / (1.0 * nx);
   zleft = 0.0, zright = xright * nz / (1.0 * nx);
   c_relax = 5;
   count = 1;
   n_level = (int)(log2(ny) + 0.001);
   /**********************/

   h = (xright - xleft) / (1.0 * nx);
   h2 = h * h;
   gam = 5 * h / (2.0 * sqrt(2) * atanh(0.9));
   cahn = pow(gam, 2);
   dt = 0.5 * 1.25e-5; // 0.5*cahn;// eps^2
   T = 2 * dt;      // 80*dt;
   max_it = (int)(T / dt + 0.5);
   ns = (int)(max_it / 2 + 0.5); /* number of printouts*/

   Sb = 2.0 / cahn;

   /********************/
   printf("nx = %d , ny = %d , nz = %d\n", nx, ny, nz);
   printf("dt      = %f\n", dt);
   printf("max_it  = %d\n", max_it);
   printf("ns      = %d\n", ns);
   printf("gam       = %f\n", gam);
   printf("h       = %f\n", h);
   printf("n_level           = %d\n", n_level);
printf("Cfdgao111");
   my = fopen("D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/rmearks.m", "w");

   
printf("Cfdgao211");
printf("Cfdgao985");
   fprintf(my, "\n\n");
   printf("Cfdgao985");
   fprintf(my, "nx      = %d\n", nx);
   fprintf(my, "ny      = %d\n", ny);
   fprintf(my, "nz      = %d\n", nz);
   fprintf(my, "dt      = %f\n", dt);
   printf("Cfdgao111");
   fprintf(my, "max_it  = %d\n", max_it);
   fprintf(my, "ns      = %d\n", ns);
   fprintf(my, "gam     = %f\n", gam);
   fprintf(my, "h       = %f\n", h);
   fclose(my);
printf("Cfdgao111");
   sorc = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   ooc = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   intc = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
printf("Cfdgao111");
   gf = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   oc = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   nc = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   c1 = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   c2 = cube(0, nx + 1, 0, ny + 1, 0, nz + 1);
   printf("Cfdgao111");

   ct = cube(1, nx, 1, ny, 1, nz);
   sc = cube(1, nx, 1, ny, 1, nz);
printf("Cfdgao111");
   initialization(oc, gf);
  printf("Cfdgao111");
   Q = 1.0;

   cube_copy(nc, oc, 1, nx, 1, ny, 1, nz);
   cube_copy(ooc, oc, 1, nx, 1, ny, 1, nz);

   augmen_phi(oc, nx, ny, nz);

   ijkloop
   {

      oE = oE + 0.5 * pow(oc[i + 1][j][k] - oc[i][j][k], 2) / (h * h) + 0.5 * pow(oc[i][j + 1][k] - oc[i][j][k], 2) / (h * h) + 0.5 * pow(oc[i][j][k + 1] - oc[i][j][k], 2) / (h * h) + 0.25 * Sb * pow(oc[i][j][k] - oc[i][j][k], 2) + 0.25 * pow(oc[i][j][k] * oc[i][j][k] - 1.0, 2.0) / cahn;
   }

   oE = oE * h * h * h;

   printf("Cfdgao111");

   print_data3(oc, count);
   count++;
   
   printf("Cfdgao111");
   augmen_phi(gf, nx, ny, nz);

   myOE = fopen("D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/Oene_2.m", "w");

   fprintf(myOE, "%16.12f \n", oE);

   for (it = 1; it <= max_it; it++)
   {

      ijkloop { intc[i][j][k] = 1.5 * oc[i][j][k] - 0.5 * ooc[i][j][k]; }

      augmen_phi(oc, nx, ny, nz);

      ijkloop
      {

         sorc[i][j][k] = oc[i][j][k] / dt - gf[i][j][k] * (-0.5 * (oc[i + 1][j][k] + oc[i - 1][j][k] + oc[i][j + 1][k] + oc[i][j - 1][k] + oc[i][j][k + 1] + oc[i][j][k - 1] - 6.0 * oc[i][j][k]) / (h * h) + 0.5 * Sb * oc[i][j][k] - Sb * intc[i][j][k]);
      }
      printf("Cfdgao");
      Heat3d(oc, c1, gf);

      ijkloop
      {

         sorc[i][j][k] = -gf[i][j][k] * (pow(intc[i][j][k], 3.0) - intc[i][j][k]) / cahn;
      }

      Heat3d(oc, c2, gf);

      // calculate auxiliary variable Q

      Q = update_q(oc, c1, c2, nx, ny, nz);

      printf("Update of Q = %10.7f \n", Q);

      ijkloop { nc[i][j][k] = c1[i][j][k] + Q * c2[i][j][k]; }

      augmen_phi(nc, nx, ny, nz);

      oE = 0.0;
      ijkloop
      {

         oE = oE + 0.5 * pow(nc[i + 1][j][k] - nc[i][j][k], 2) / (h * h) + 0.5 * pow(nc[i][j + 1][k] - nc[i][j][k], 2) / (h * h) + 0.5 * pow(nc[i][j][k + 1] - nc[i][j][k], 2) / (h * h) + 0.25 * Sb * pow(nc[i][j][k] - oc[i][j][k], 2) + 0.25 * pow(nc[i][j][k] * nc[i][j][k] - 1.0, 2) / cahn;
      }

      oE = oE * h * h * h;

      cube_copy(ooc, oc, 1, nx, 1, ny, 1, nz);
      cube_copy(oc, nc, 1, nx, 1, ny, 1, nz);

      printf("iteration=   %d \n", it);

      if ((it % ns == 0))
      {

         print_data3(oc, count);
         count++;

         fprintf(myOE, "%16.12f \n", oE);

         printf("\n counts=   %d \n", count);
         end = clock();
         elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;
         printf("Time elapsed %f\n", elapsed);
         my = fopen("D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/remarks.m", "a");
         fprintf(my, "\n counts=    %d     CPU Time=   %f\n", count - 1, elapsed);
         fclose(my);
      }
   }

   end = clock();
   elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;

   my = fopen("D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/remarks.m", "a");
   fprintf(my, "\n Finally time elapsed %f\n", elapsed);
   fclose(my);

   return 0;
}

double update_q(double ***oc, double ***c1, double ***c2, int nx, int ny, int nz)
{
   extern double h, ***intc;
   double t1, t2, t3, t4, t5, F, F2, res, tol, resid, nq, q;
   int i, j, k, kk = 1;

   t1 = 0.0;
   t2 = 0.0;
   t3 = 0.0;
   t4 = 0.0;
   t5 = 0.0;

   q = 1.0;

   tol = 1.0e-4;
   resid = 1.0;

   ijkloop
   {

      t1 = t1 + h * h * h * pow(c2[i][j][k], 4) / 4.0;
      t2 = t2 + h * h * h * (c1[i][j][k] * pow(c2[i][j][k], 3.0));
      t3 = t3 + h * h * h * (1.5 * pow(c1[i][j][k], 2.0) * pow(c2[i][j][k], 2.0) - 0.5 * pow(c2[i][j][k], 2.0) - c2[i][j][k] * (pow(intc[i][j][k], 3.0) - intc[i][j][k]));
      t4 = t4 + h * h * h * (pow(c1[i][j][k], 3.0) * c2[i][j][k] - c1[i][j][k] * c2[i][j][k] - (c1[i][j][k] - oc[i][j][k]) * (pow(intc[i][j][k], 3.0) - intc[i][j][k]));
      t5 = t5 + h * h * h * (0.25 * pow(c1[i][j][k], 4.0) - 0.5 * pow(c1[i][j][k], 2.0) - pow(oc[i][j][k] * oc[i][j][k] - 1.0, 2.0) / 4.0 + 0.25);
   }

   F = pow(q, 4) * t1 + pow(q, 3) * t2 + pow(q, 2) * t3 + q * t4 + t5;
   F2 = 4.0 * pow(q, 3) * t1 + 3.0 * pow(q, 2) * t2 + 2.0 * q * t3 + t4;

   while (kk <= 500 && resid > tol)
   {

      nq = q - 0.0001 * F / F2;

      resid = fabs(nq - q);

      q = nq;

      kk++;
   }

   res = q;

   return res;
}

void initialization(double ***phi, double ***gf)
{
   extern double h;
   double gam2;
   double valuexyz;
   FILE *fp;
   int i, j, k, ik, npo, ia, ja, ka, msize;
   double x, y, z, d, length, max_mun = -1.0;
   gam2 = 2.5 * h / (2.0 * sqrt(2) * atanh(0.9));
   length = 2.0 * h;

   fp = fopen("D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/nt_points.m", "r");
   fscanf(fp, "%lf", &valuexyz);
   npo = (int)(valuexyz + 0.01);
   fclose(fp);
   fp = fopen("D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/fun.m", "r");

   ijkloop
   {
      phi[i][j][k] = 1.0;
   }

   msize = (int)(gam2 / h * 6 + 0.1);
   for (ik = 1; ik <= npo; ik++)
   {
     fscanf(fp, "%lf", &valuexyz);
      x = valuexyz;
      fscanf(fp, "%lf", &valuexyz);
      y = valuexyz;
      fscanf(fp, "%lf", &valuexyz);
      z = valuexyz;
      ia = (int)(x / h + 0.499999) - 1;
      ja = (int)(y / h + 0.499999) - 1;
      ka = (int)(z / h + 0.499999) - 1;

      for (i = ia - msize + 1; i <= ia + msize; i++)
      {

         for (j = ja - msize + 1; j <= ja + msize; j++)
         {

            for (k = ka - msize + 1; k <= ka + msize; k++)
            {

               d = sqrt(pow((i - 0.5) * h - x, 2) + pow((j - 0.5) * h - y, 2) + pow((k - 0.5) * h - z, 2));
               if (d < phi[i][j][k])
               {
                  phi[i][j][k] = d;
               }
            }
         }
      }
  
   }

   fclose(fp);
   ijkloop
   {
      phi[i][j][k] = -tanh((phi[i][j][k] - 1*sqrt(2) * gam2 - 2.0 * h) / (sqrt(2) * gam2));
      gf[i][j][k] = 1.0 - phi[i][j][k] * phi[i][j][k] + 1.0e-10;
   }
}

void Heat3d(double ***c_old, double ***c_new, double ***gf)
{
   extern int nx, ny, nz;
   extern double gam, lamm, h, Sb, dt, HH, ***sorc, ***intc;

   int i, j, k, max_it_CH = 100, it_mg = 1;
   double tol = 1.0e-6, resid = 1.0;

   double ***sor1;
   sor1 = cube(1, nx, 1, ny, 1, nz);

   cube_copy(sor1, c_new, 1, nx, 1, ny, 1, nz);

   while (it_mg <= max_it_CH && resid > tol)
   {

      vcycle(c_new, sorc, gf, nx, ny, nz, 1);
      resid = error3(sor1, c_new, nx, ny, nz);
      cube_copy(sor1, c_new, 1, nx, 1, ny, 1, nz);
      it_mg++;
   }

   printf("Vel: Heat equation iteration = %d  residual = %10.7f \n", it_mg, resid);

   free_cube(sor1, 1, nx, 1, ny, 1, nz);

   return;
}

void vcycle(double ***uf_new, double ***su, double ***gf, int nxf, int nyf, int nzf, int ilevel)
{
   extern int n_level;
   extern double Sb, dt;

   relax(uf_new, su, gf, ilevel, nxf, nyf, nzf);
}

void relax(double ***c, double ***sc, double ***gf, int ilevel, int nxt, int nyt, int nzt)
{

   extern double dt, Sb, xleft, xright;
   extern int c_relax;
   int i, j, k, ik;
   double ht2, x_fac, y_fac, z_fac, a[1], f[1], xs, xl, ys, yl, zs, zl;

   ht2 = pow((xright - xleft) / (double)nxt, 2);

   xs = 1.0;
   xl = 1.0;
   ys = 1.0;
   yl = 1.0;
   zs = 1.0;
   zl = 1.0;
   for (ik = 0; ik < c_relax; ik++)
      ijkloopt
      {

         f[0] = 0.0;

         if (i == 1)
         {
            x_fac = xl;
            f[0] += c[i + 1][j][k] * xl;
         }
         else if (i == nxt)
         {
            x_fac = xs;
            f[0] += c[i - 1][j][k] * xs;
         }
         else
         {
            x_fac = xs + xl;
            f[0] += c[i - 1][j][k] * xs + c[i + 1][j][k] * xl;
         }

         if (j == 1)
         {
            y_fac = yl;
            f[0] += c[i][j + 1][k] * yl;
         }
         else if (j == nyt)
         {
            y_fac = ys;
            f[0] += c[i][j - 1][k] * ys;
         }
         else
         {
            y_fac = ys + yl;
            f[0] += c[i][j - 1][k] * ys + c[i][j + 1][k] * yl;
         }

         if (k == 1)
         {
            z_fac = zl;
            f[0] += c[i][j][k + 1] * zl;
         }
         else if (k == nzt)
         {
            z_fac = zs;
            f[0] += c[i][j][k - 1] * zs;
         }
         else
         {
            z_fac = zs + zl;
            f[0] += c[i][j][k - 1] * zs + c[i][j][k + 1] * zl;
         }

         a[0] = 1.0 / dt + 0.5 * Sb * gf[i][j][k] + 0.5 * (x_fac + y_fac + z_fac) / ht2 * gf[i][j][k];
         f[0] = 0.5 * f[0] / ht2 * gf[i][j][k] + sc[i][j][k];

         c[i][j][k] = f[0] / a[0];
      }
}

double cube_max(double ***c, int nxt, int nyt, int nzt)
{
   int i, j, k;
   double value = 0.0;

   ijkloop
   {

      if (fabs(c[i][j][k]) > value)
         value = fabs(c[i][j][k]);
   }

   return value;
}

double error3(double ***c_old, double ***c_new, int nxt, int nyt, int nzt)
{
   extern int nx, ny, nz;

   int i, j, k;
   double value;

   value = 0.0;

   ijkloop
   {
      value += pow(c_old[i][j][k] - c_new[i][j][k], 2);
   }

   value = sqrt(value / (1.0 * nx * ny * nz));

   return value;
}

void print_data3(double ***c, int count)
{
   char buffer[200];
   FILE *fc;
   int i, j, k;

   printf("Cfdgao2222");
   sprintf(buffer, "D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/phi%d.m", count);
   printf("Cfdgao3333");
   fc = fopen(buffer, "w");
   printf("Cfdgao4444");
   ijkloop
   {
      fprintf(fc, " %10.7f\n", c[i][j][k]);
   }

   printf("Cfdgao5555");
   fclose(fc);

   return;
}

double error(double ***c_old, double ***c_new, int nxt, int nyt, int nzt)
{
   extern int nx, ny, nz;

   int i, j, k;
   double value;

   value = 0.0;

   ijkloop
   {
      value += pow(c_old[i][j][k] - c_new[i][j][k], 2);
   }

   value = sqrt(value / (1.0 * nx * ny * nz));

   return value;
}

/************* util *****************/

double ***cube(int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, nrow = xr - xl + 1, ncol = yr - yl + 1, ndep = zr - zl + 1;
   double ***t;

   t = (double ***)malloc(((nrow + 1) * sizeof(double **)));
   t += 1;
   t -= xl;

   t[xl] = (double **)malloc(((nrow * ncol + 1) * sizeof(double *)));
   t[xl] += 1;
   t[xl] -= yl;

   t[xl][yl] = (double *)malloc(((nrow * ncol * ndep + 1) * sizeof(double)));
   t[xl][yl] += 1;
   t[xl][yl] -= zl;

   for (j = yl + 1; j <= yr; j++)
      t[xl][j] = t[xl][j - 1] + ndep;
   for (i = xl + 1; i <= xr; i++)
   {
      t[i] = t[i - 1] + ncol;
      t[i][yl] = t[i - 1][yl] + ncol * ndep;
      for (j = yl + 1; j <= yr; j++)
         t[i][j] = t[i][j - 1] + ndep;
   }

   return t;
}

void free_cube(double ***t, int xl, int xr, int yl, int yr, int zl, int zr)
{
   free((char *)(t[xl][yl] + zl - 1));
   free((char *)(t[xl] + yl - 1));
   free((char *)(t + xl - 1));
}

double *dvector(long nl, long nh)
/* allocate a double  vector with subscript range v[nl..nh] */
{
   double *v;

   v = (double *)malloc((nh - nl + 1 + NR_END) * sizeof(double));
   return v - nl + NR_END;
}

double **dmatrix(long nrl, long nrh, long ncl, long nch)
{
   double **m;
   long i, nrow = nrh - nrl + 1 + NR_END, ncol = nch - ncl + 1 + NR_END;

   m = (double **)malloc((nrow) * sizeof(double *));
   m += NR_END;
   m -= nrl;

   m[nrl] = (double *)malloc((nrow * ncol) * sizeof(double));
   m[nrl] += NR_END;

   m[nrl] -= ncl;

   for (i = nrl + 1; i <= nrh; i++)
      m[i] = m[i - 1] + ncol;

   return m;
}

void free_dvector(double *v, long nl, long nh)
{
   free(v + nl - NR_END);

   return;
}

void free_dmatrix(double **m, long nrl, long nrh, long ncl, long nch)
{
   free(m[nrl] + ncl - NR_END);
   free(m + nrl - NR_END);

   return;
}

double sum_cube(double ***a, int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;
   double sum = 0.0;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
            sum += a[i][j][k];

   return sum;
}

void zero_cube(double ***a, int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = 0.0;
         }

   return;
}

void zero_cube2(double ***a, double ***b,
                int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k] = 0.0;
         }

   return;
}

void cube_add(double ***a, double ***b, double ***c,
              int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k] + c[i][j][k];
         }

   return;
}

void cube_add2(double ***a, double ***b, double ***c,
               double ***a2, double ***b2, double ***c2,
               int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k] + c[i][j][k];
            a2[i][j][k] = b2[i][j][k] + c2[i][j][k];
         }

   return;
}

void cube_sub(double ***a, double ***b, double ***c,
              int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k] - c[i][j][k];
         }

   return;
}

void cube_sub2(double ***a, double ***b, double ***c,
               double ***a2, double ***b2, double ***c2,
               int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k] - c[i][j][k];
            a2[i][j][k] = b2[i][j][k] - c2[i][j][k];
         }

   return;
}

void cube_copy(double ***a, double ***b,
               int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k];
         }

   return;
}

void cube_copy2(double ***a, double ***b,
                double ***a2, double ***b2,
                int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i = xl; i <= xr; i++)
      for (j = yl; j <= yr; j++)
         for (k = zl; k <= zr; k++)
         {

            a[i][j][k] = b[i][j][k];
            a2[i][j][k] = b2[i][j][k];
         }

   return;
}

void augmen_phi(double ***c, int nxt, int nyt, int nzt)
{

   int i, j, k;

   for (j = 1; j <= nyt; j++)
      for (k = 1; k <= nzt; k++)
      {

         c[0][j][k] = c[1][j][k];
         c[nxt + 1][j][k] = c[nxt][j][k];
      }

   for (i = 0; i <= nxt + 1; i++)
      for (k = 1; k <= nzt; k++)
      {

         c[i][0][k] = c[i][1][k];
         c[i][nyt + 1][k] = c[i][nyt][k];
      }

   for (i = 0; i <= nxt + 1; i++)
      for (j = 0; j <= nyt + 1; j++)
      {

         c[i][j][0] = c[i][j][1];
         c[i][j][nzt + 1] = c[i][j][nzt];
      }
}
