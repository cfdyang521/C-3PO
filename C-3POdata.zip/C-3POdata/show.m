%clc;
clear;
%close all

% nx=32;
nx=300;
ny=300;
nz=600;
mp=1;
h=1.0/nx;
x=linspace(0.5*h,0.5-0.5*h,nx);
y=linspace(0.5*h,0.5-0.5*h,ny);
z=linspace(0.5*h,1-0.5*h,nz);
[xx,yy,zz]=meshgrid(y,x,z);

for ip=2
% ss=sprintf('D:/LEARINING/3d reconstruction/LagrangeMultiplier/LagrangeMultiplier_dragon/phi%d.m',ip);


ss=sprintf('D:\\LEARINING\\3d reconstruction\\LagrangeMultiplier\\C-3POdata/phi%d.m',ip);

% ss=sprintf('data2/phi%d.m',ip);
u=load(ss);
S(1:nx,1:ny,1:nz)=0;
for k=1:nz
    for j=1:ny
        for i=1:nx
           % aa=u(nx*ny*(k-1)+ny*(j-1)+i);
             aa=u(ny*nz*(i-1)+nz*(j-1)+k);
            S(i,j,k)=aa;
            %          if(y(i) < 0.25)
             %     S(i,j,k) = -1;
            %end
        end
    end
end

figure(ip+3)
S(1,1,1)=0.01;
S(nx,ny,nz)=0.01;
p=patch(isosurface(xx,yy,zz,S,-0.0));
set(p,'FaceColor',[0.93 0.69 0.13],'EdgeColor','none');
daspect([1 1 1])
view(-116,11)
camlight;lighting phong;
axis image;
axis off
axis([0 0.5 0 0.5 0 1])


end
% 
% figure
% mesh(S(:,:,nx/2))

