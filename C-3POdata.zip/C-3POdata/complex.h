
void initialization(double ***phi,double ***gf);

double update_q(double ***oc, double ***c1, double ***c2, int nx, int ny, int nz);

//double delta(double x);
void Heat3d(double ***c_old, double ***c_new, double ***gf);

void vcycle(double ***uf_new, double ***su,double ***gf, int nxf, int nyf, int nzf, int ilevel);

void relax(double ***c, double ***sc,double ***gf, int ilevel, int nxt, int nyt, int nzt);

void restrict1(double ***uf, double ***uc, int nxt, int nyt, int nzt);

void prolong(double ***uc, double ***uf, int nxt, int nyt, int nzt);
double cube_max(double ***c, int nxt, int nyt, int nzt);
double error(double ***c_old, double ***c_new, int nxt, int nyt, int nzt);
void laplace_ch_gf(double ***a, double ***lap_a,double ***gf, int nxt, int nyt, int nzt);
double error3(double ***c_old, double ***c_new, int nxt, int nyt, int nzt);
void cahn1(double ***c_old, double ***c_new);
void print_data3( double ***c, int count);
void source(double ***c_old, double ***src_c);