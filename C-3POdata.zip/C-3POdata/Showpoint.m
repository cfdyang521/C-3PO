ss=sprintf('D:/LEARINING/3d reconstruction/LagrangeMultiplier/pointCloud_Generation/c3po2/fun.m');
u=load(ss);hold on;
u1 = u(1:3:end);
u2 = u(2:3:end);
u3 = u(3:3:end);
hold on;figure(5);
plot3(u2(1:10:end),u1(1:10:end),u3(1:10:end),'k.','markersize',2);
axis image;
view(-53,0)
axis off;