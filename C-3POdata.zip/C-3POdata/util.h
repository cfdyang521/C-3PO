#define resolution 600

#define gnx 300
#define gny 300
#define gnz resolution

#define iloop for(i=1;i<=gnx;i++)
#define jloop for(j=1;j<=gny;j++)
#define kloop for(k=1;k<=gnz;k++)
#define ijkloop iloop jloop kloop
#define kjiloop kloop jloop iloop

#define iloopp for(i=0;i<=gnx;i++)
#define jloopp for(j=0;j<=gny;j++)
#define kloopp for(k=0;k<=gnz;k++)
#define ijkloopp iloopp jloopp kloopp
#define kjiloopp kloopp jloopp iloopp

#define iloopt for(i=1;i<=nxt;i++)
#define jloopt for(j=1;j<=nyt;j++)
#define kloopt for(k=1;k<=nzt;k++)
#define ijkloopt iloopt jloopt kloopt
#define kjiloopt kloopt jloopt iloopt



double  ***cube(int xl, int xr, int yl, int yr, int zl, int zr);


void free_cube(double  ***t, int xl, int xr, int yl, int yr, int zl, int zr);



double  *dvector (long nl, long nh);


double  **dmatrix(long nrl, long nrh, long ncl, long nch);


void free_dvector(double  *v, long nl, long nh);


void free_dmatrix(double  **m, long nrl, long nrh, long ncl, long nch);



double sum_cube(double ***a, int xl, int xr, int yl, int yr, int zl, int zr);


void zero_cube(double  ***a, int xl, int xr, int yl, int yr, int zl, int zr);


void zero_cube2(double  ***a, double  ***b, 
                int xl, int xr, int yl, int yr, int zl, int zr);

void print_data(double  ***phi);

void cube_add(double  ***a, double  ***b, double  ***c, 
              int xl, int xr, int yl, int yr, int zl, int zr);


void cube_add2(double  ***a, double  ***b, double  ***c, 
              double  ***a2, double  ***b2, double  ***c2, 
              int xl, int xr, int yl, int yr, int zl, int zr);

void cube_sub(double  ***a, double  ***b, double  ***c, 
              int xl, int xr, int yl, int yr, int zl, int zr);



void cube_sub2(double  ***a, double  ***b, double  ***c, 
               double  ***a2, double  ***b2, double  ***c2, 
               int xl, int xr, int yl, int yr, int zl, int zr);




void cube_copy(double  ***a, double  ***b, 
              int xl, int xr, int yl, int yr, int zl, int zr);

void cube_copy2(double  ***a, double  ***b,
                double  ***a2, double  ***b2,
                int xl, int xr, int yl, int yr, int zl, int zr);


void augmenc(double ***c);

void augmen_phi(double ***c,int nxt,int nyt,int nzt);
