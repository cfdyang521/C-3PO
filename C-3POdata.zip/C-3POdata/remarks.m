

nx      = 256
ny      = 256
nz      = 256
dt      = 0.000006
max_it  = 10
ns      = 1
gam     = 0.003752
h       = 0.003906

 counts=    2     CPU Time=   27.069000

 counts=    3     CPU Time=   44.223000

 counts=    4     CPU Time=   63.098000

 counts=    5     CPU Time=   81.446000

 counts=    6     CPU Time=   99.323000

 counts=    7     CPU Time=   117.186000

 counts=    8     CPU Time=   134.685000

 counts=    9     CPU Time=   151.071000

 counts=    10     CPU Time=   167.796000

 counts=    11     CPU Time=   184.734000

 Finally time elapsed 184.736000

 counts=    2     CPU Time=   26.590000

 counts=    3     CPU Time=   43.779000

 counts=    4     CPU Time=   60.851000

 counts=    5     CPU Time=   78.910000

 counts=    6     CPU Time=   94.877000

 counts=    7     CPU Time=   110.525000

 counts=    8     CPU Time=   126.508000

 counts=    9     CPU Time=   142.716000

 counts=    10     CPU Time=   158.204000

 counts=    11     CPU Time=   173.120000

 Finally time elapsed 173.122000

 counts=    2     CPU Time=   227.787000

 counts=    3     CPU Time=   452.817000

 counts=    4     CPU Time=   661.354000

 counts=    5     CPU Time=   869.785000

 counts=    6     CPU Time=   1094.754000

 counts=    7     CPU Time=   1304.263000

 counts=    8     CPU Time=   1518.409000

 counts=    9     CPU Time=   1717.294000

 counts=    10     CPU Time=   1944.393000

 counts=    11     CPU Time=   2167.651000

 Finally time elapsed 2167.655000

 counts=    2     CPU Time=   202.987000

 counts=    3     CPU Time=   368.847000

 counts=    4     CPU Time=   561.878000

 counts=    5     CPU Time=   745.104000

 counts=    6     CPU Time=   908.442000

 counts=    2     CPU Time=   207.137000

 counts=    3     CPU Time=   368.861000

 counts=    4     CPU Time=   559.084000

 counts=    5     CPU Time=   764.551000

 Finally time elapsed 764.553000

 counts=    2     CPU Time=   233.917000

 counts=    3     CPU Time=   421.900000

 counts=    4     CPU Time=   603.875000

 counts=    5     CPU Time=   788.994000

 Finally time elapsed 788.997000

 counts=    2     CPU Time=   185.121000

 counts=    3     CPU Time=   327.723000

 counts=    4     CPU Time=   475.432000

 counts=    5     CPU Time=   624.347000

 Finally time elapsed 624.350000

 counts=    2     CPU Time=   183.477000

 counts=    3     CPU Time=   314.268000

 counts=    4     CPU Time=   446.974000

 counts=    5     CPU Time=   571.677000

 Finally time elapsed 571.679000

 counts=    2     CPU Time=   23.986000

 counts=    2     CPU Time=   48.177000

 counts=    3     CPU Time=   82.489000

 counts=    4     CPU Time=   119.370000

 counts=    5     CPU Time=   155.179000

 Finally time elapsed 155.180000

 counts=    2     CPU Time=   48.062000

 counts=    3     CPU Time=   82.807000

 counts=    4     CPU Time=   117.629000

 counts=    5     CPU Time=   152.311000

 Finally time elapsed 152.313000

 counts=    2     CPU Time=   53.510000

 counts=    3     CPU Time=   89.292000

 counts=    4     CPU Time=   124.322000

 counts=    5     CPU Time=   161.576000

 Finally time elapsed 161.577000

 counts=    2     CPU Time=   83.628000

 counts=    3     CPU Time=   140.113000

 counts=    4     CPU Time=   199.171000

 counts=    5     CPU Time=   257.884000

 Finally time elapsed 257.886000

 counts=    2     CPU Time=   81.713000

 counts=    3     CPU Time=   136.055000

 counts=    4     CPU Time=   191.586000

 counts=    5     CPU Time=   248.130000

 Finally time elapsed 248.131000

 counts=    2     CPU Time=   81.269000

 counts=    2     CPU Time=   81.630000

 counts=    3     CPU Time=   135.700000

 Finally time elapsed 135.701000

 counts=    2     CPU Time=   76.721000

 counts=    3     CPU Time=   130.613000

 Finally time elapsed 130.615000

 counts=    2     CPU Time=   66.974000

 counts=    3     CPU Time=   111.534000

 Finally time elapsed 111.539000

 counts=    2     CPU Time=   86.851000

 counts=    3     CPU Time=   153.086000

 Finally time elapsed 153.088000

 counts=    2     CPU Time=   109.983000

 counts=    3     CPU Time=   188.561000

 Finally time elapsed 188.562000

 counts=    2     CPU Time=   94.727000

 counts=    3     CPU Time=   175.767000

 Finally time elapsed 175.768000

 counts=    2     CPU Time=   115.298000

 counts=    3     CPU Time=   207.361000

 Finally time elapsed 207.362000

 counts=    2     CPU Time=   96.175000

 counts=    3     CPU Time=   163.715000

 Finally time elapsed 163.717000

 counts=    2     CPU Time=   84.868000

 counts=    3     CPU Time=   149.453000

 Finally time elapsed 149.455000

 counts=    2     CPU Time=   106.434000

 counts=    3     CPU Time=   177.695000

 Finally time elapsed 177.697000

 counts=    2     CPU Time=   369.838000

 counts=    3     CPU Time=   815.554000

 Finally time elapsed 815.558000

 counts=    2     CPU Time=   136.319000

 counts=    3     CPU Time=   252.064000

 Finally time elapsed 252.067000

 counts=    2     CPU Time=   148.343000

 counts=    3     CPU Time=   275.798000

 Finally time elapsed 275.799000

 counts=    2     CPU Time=   87.356000

 counts=    3     CPU Time=   166.583000

 Finally time elapsed 166.585000

 counts=    2     CPU Time=   813.656000

 counts=    2     CPU Time=   81.977000

 counts=    3     CPU Time=   140.701000

 Finally time elapsed 140.703000
