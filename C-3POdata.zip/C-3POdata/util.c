#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <math.h>
#include "util.h"
#include "complex.h"
#define NR_END 1

double  ***cube(int xl, int xr, int yl, int yr, int zl, int zr)
{
  int i,j,nrow=xr-xl+1, ncol=yr-yl+1, ndep=zr-zl+1;
  double  ***t;
  
  t = (double  ***) malloc(((nrow+1)*sizeof(double **)));
  t += 1;
  t -= xl;

  t[xl]=(double  **) malloc(((nrow*ncol+1)*sizeof(double  *)));
  t[xl] += 1;
  t[xl] -= yl;

  t[xl][yl] = (double  *) malloc(((nrow*ncol*ndep+1)*sizeof(double ))); 
  t[xl][yl] += 1;
  t[xl][yl] -= zl;

  for(j=yl+1; j<=yr; j++)
     t[xl][j]=t[xl][j-1]+ndep;
  for(i=xl+1; i<=xr; i++)
    {
       t[i] = t[i-1]+ncol;
       t[i][yl] = t[i-1][yl]+ncol*ndep;
    for(j=yl+1; j<=yr; j++)
       t[i][j] = t[i][j-1]+ndep;
    }

  return t;
} 


void free_cube(double  ***t, int xl, int xr, int yl, int yr, int zl, int zr)
{
   free((char *) (t[xl][yl]+zl-1));
   free((char *) (t[xl]+yl-1));
   free((char *) (t+xl-1));
}


double  *dvector (long nl, long nh)
/* allocate a double  vector with subscript range v[nl..nh] */
{
   double  *v;

   v=(double  *) malloc((nh-nl+1+NR_END)*sizeof(double ));
   return v-nl+NR_END;

}

double  **dmatrix(long nrl, long nrh, long ncl, long nch)
{
   double  **m;
   long i, nrow=nrh-nrl+1+NR_END, ncol=nch-ncl+1+NR_END;

   m=(double  **) malloc((nrow)*sizeof(double *));
   m+=NR_END;
   m-=nrl;

   m[nrl]=(double  *) malloc((nrow*ncol)*sizeof(double ));
   m[nrl]+=NR_END;

   m[nrl]-=ncl;

   for (i=nrl+1; i<=nrh; i++) m[i]=m[i-1]+ncol;

   return m;
}


void free_dvector(double  *v, long nl, long nh)
{
   free (v+nl-NR_END);

   return;
}

void free_dmatrix(double  **m, long nrl, long nrh, long ncl, long nch)
{
   free(m[nrl]+ncl-NR_END);
   free(m+nrl-NR_END);

   return;
}



double sum_cube(double ***a, int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;
   double sum = 0.0;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
	 for (k=zl; k<=zr; k++)    
          sum += a[i][j][k];     

   return sum;
}

void zero_cube(double  ***a, int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k] = 0.0;
	 
  }

   return;   
}

void zero_cube2(double  ***a, double  ***b, 
                int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k] = b[i][j][k] = 0.0;
	 
  }

   return;   
}




void cube_add(double  ***a, double  ***b, double  ***c, 
              int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k]=b[i][j][k]+c[i][j][k];
	 
        }

   return;
}

void cube_add2(double  ***a, double  ***b, double  ***c, 
              double  ***a2, double  ***b2, double  ***c2, 
              int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k]=b[i][j][k]+c[i][j][k];
        a2[i][j][k]=b2[i][j][k]+c2[i][j][k];
	 
        }

   return;
}




void cube_sub(double  ***a, double  ***b, double  ***c, 
              int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k]=b[i][j][k]-c[i][j][k];
	 
        }

   return;
}


void cube_sub2(double  ***a, double  ***b, double  ***c, 
               double  ***a2, double  ***b2, double  ***c2, 
               int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k]=b[i][j][k]-c[i][j][k];
        a2[i][j][k]=b2[i][j][k]-c2[i][j][k];	 

        }

   return;
}




void cube_copy(double  ***a, double  ***b, 
              int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k]=b[i][j][k];
	 
        }

   return;
}

void cube_copy2(double  ***a, double  ***b,
                double  ***a2, double  ***b2,
                int xl, int xr, int yl, int yr, int zl, int zr)
{
   int i, j, k;

   for (i=xl; i<=xr; i++)
      for (j=yl; j<=yr; j++)
         for (k=zl; k<=zr; k++){

        a[i][j][k]=b[i][j][k];
        a2[i][j][k]=b2[i][j][k];
	 
        }

   return;
}



void augmen_phi(double ***c,int nxt,int nyt,int nzt)
{

  int i, j, k;

   for (j=1; j<=nyt; j++)
       for (k=1; k<=nzt; k++) {
           
           c[0][j][k] = c[1][j][k];
           c[nxt+1][j][k] = c[nxt][j][k];
   }
   
   for (i=0; i<=nxt+1; i++)
       for (k=1; k<=nzt; k++) {
           
           c[i][0][k] = c[i][1][k];
           c[i][nyt+1][k] = c[i][nyt][k];
   }
   
   for (i=0; i<=nxt+1; i++)
       for (j=0; j<=nyt+1; j++) {
           
           c[i][j][0] = c[i][j][1];
           c[i][j][nzt+1] = c[i][j][nzt];
   }
} 

